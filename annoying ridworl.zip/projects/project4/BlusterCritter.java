/**
 * @author Roko Gebbie
 * @since 3/21/24
 * 
*/
import info.gridworld.actor.Actor;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.util.ArrayList;
import java.awt.Color;
public class BlusterCritter extends Critter
{
    private int nearby;

    public BlusterCritter(int c)
    {
        super();
        nearby = c;
    }

    public void processActors(ArrayList<Actor> actors)
    {
        int count = 0;
        for(Actor a: actors){
            if(a instanceof Critter)    
                count++;
            if(count < nearby)
                lighten();
            else
                darken();
        }
    }

    public void darken(){
        int r = (int) (getColor().getRed() * (0.75));
        int g = (int) (getColor().getGreen() * (0.75));
        int b = (int) (getColor().getBlue() * (0.75));
        setColor(new Color(r,g,b)); 
    }

    public ArrayList<Actor> getActors() {
        ArrayList<Actor> actors = new ArrayList<Actor>();
        Location currentLocation = getLocation();
    
        int startRow = currentLocation.getRow() - 2;
        int endRow = currentLocation.getRow() + 2;
        int startCol = currentLocation.getCol() - 2;
        int endCol = currentLocation.getCol() + 2;
    
        for (int row = startRow; row <= endRow; row++) {
            for (int col = startCol; col <= endCol; col++) {
                Location temp = new Location(row, col);
    
                if (getGrid().isValid(temp)) {
                    Actor actor = getGrid().get(temp);
                    if (actor != null && actor != this) {
                        actors.add(actor);
                    }
                }
            }
        }
        return actors;
    }
    

    public void lighten(){
        int r = getColor().getRed() +1;
        int g = getColor().getRed() +1;
        int b = getColor().getBlue() +1;
        if(r > 255)
            r--;
        if(g > 255)
            g--;
        if(b > 255)
            b--;  
        setColor(new Color(r,g,b)); 
    }
} 