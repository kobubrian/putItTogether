/**
 * @author Roko Gebbie
 * @since 3/21/24
 * 
*/
import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;
public class QuickCrab extends CrabCritter {

    public ArrayList<Location> getMoveLocations() {
        ArrayList<Location> potentialMoves = new ArrayList<Location>();
        Grid grid = getGrid();
        Location currentLocation = getLocation();

        int[] directions = { Location.LEFT, Location.RIGHT }; 

        for (int dir : directions) {
            Location nextLocation = currentLocation.getAdjacentLocation(getDirection() + dir);
            if (grid.isValid(nextLocation) && grid.get(nextLocation) == null) {
                Location finalLocation = nextLocation.getAdjacentLocation(getDirection() + dir);
                if (grid.isValid(finalLocation) && grid.get(finalLocation) == null)
                    potentialMoves.add(finalLocation);
            }
        }

        if (potentialMoves.size() == 0)
            return super.getMoveLocations();

        return potentialMoves;
    }
}
