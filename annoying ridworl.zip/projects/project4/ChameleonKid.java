/**
 * @author Roko Gebbie
 * @since 3/21/24
 * 
*/

import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.awt.Color;
import java.util.ArrayList; 

public class ChameleonKid extends ChameleonCritter{
	int turnCount;
	ArrayList<Location> locs; 
	 /**
     * Constructs a blue JumperBug.
     */
	public ChameleonKid(){
		turnCount = 0;		
	}
	/**
	 * moves the bug around
	 */
	public void act(){
		Location go = selectMoveLocation(getMoveLocations());
		makeMove(go);
		processActors(getActors());
	}  
}
