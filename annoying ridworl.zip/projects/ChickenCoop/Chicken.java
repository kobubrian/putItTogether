import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;

import java.awt.Color;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import java.util.ArrayList;

public class Chicken extends Critter {
    private int steps;
    public Chicken(){
        steps = 0;
        setColor(Color.WHITE);
    }
    public void makeMove(Location loc){
        int turnOrMove = (int) (Math.random() * 2) +1;
        if(steps < 200){
            if(turnOrMove == 1){
                setDirection((int)(Math.random() * 8));
            }
            else if (turnOrMove == 2){
                Location lastLoc = getLocation();
                Grid<Actor> gr = getGrid();
                moveTo(loc);
                if(((int) (Math.random() * 20) +1) == 15){// random value
                    Egg egg = new Egg();
                    egg.putSelfInGrid(gr, lastLoc);
                }
            }
        }
        else if(steps > 199 && steps < 280 && steps % 2 == 0){
            if(turnOrMove == 1){
                setDirection((int)(Math.random() * 8));
            }
            else if (turnOrMove == 2){
                moveTo(loc);
            }
        }
        else if(steps > 279 && steps % 4 == 0){
            darken();
            if(turnOrMove == 1){
                setDirection((int)(Math.random() * 8));
            }
            else if (turnOrMove == 2){
                moveTo(loc);
            }
        }
        if(steps > 299){
            Grid<Actor> gr = getGrid();
            Tombstone dead = new Tombstone();
            dead.putSelfInGrid(gr, getLocation());
        }
            
        steps++;
    }
    public void darken(){
        int r = (int) (getColor().getRed() * (0.75));
        int g = (int) (getColor().getGreen() * (0.75));
        int b = (int) (getColor().getBlue() * (0.75));
        setColor(new Color(r,g,b)); 
    }
}
