import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;

import java.awt.Color;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import java.awt.Color;
import java.util.ArrayList;

public class Egg extends Actor{
    private int steps;
    public Egg(){
        steps = 0;
        setColor(Color.WHITE);
    }
    public void act(){
        darken();
        if(steps == 45)
            setColor(Color.RED);
        else if (steps == 50){
            Grid<Actor> gr = getGrid();
            Chicken chick = new Chicken();
            chick.putSelfInGrid(gr, getLocation());
        }
    }
    public void darken(){
        int r = (int) (getColor().getRed() * (0.85));
        int g = (int) (getColor().getGreen() * (0.85));
        int b = (int) (getColor().getBlue() * (0.85));
        setColor(new Color(r,g,b)); 
    }
}
