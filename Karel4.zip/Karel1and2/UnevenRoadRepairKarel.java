
/*
 * File: UnevenRoadRepairKarel.java
 * -----------------------------
 * The UnevenRoadRepairKarel class extends the basic Karel class
 * so that Karel fills a pothole with a beeper.
 */

import stanford.karel.*;

public class UnevenRoadRepairKarel extends SuperKarel {

	public void run() {
		for(int a = 1;a<10;a++){
			if(mayI() == true)
				fillPot();
		}
	}
	public void fillPot(){
		turnRight();
		safeMove();
		if(noBeepersPresent())
			putBeeper();
		turnLeft();
		turnLeft();
		safeMove();
		turnRight();
		safeMove();
	}
	public void safeMove(){
		if(!frontIsBlocked())
			move();
	}
	public boolean mayI(){
		turnRight();
		if(frontIsBlocked()){
			turnLeft();
			move();
			return false;
		}
		turnLeft();
		return true;
	}
	
}
