/*
 * File: CheckerboardKarel.java
 * ----------------------------
 * When you finish writing it, the CheckerboardKarel class should draw
 * a checkerboard using beepers, as described in Assignment Karel4.  You
 * should make sure that your program works for all of the sample
 * worlds supplied in the starter folder.
 */

import stanford.karel.*;

public class CheckerboardKarel extends SuperKarel {

	public void run() {
		//dirTest();
		//for(int a = 0; a<3;a++){
			lineFiller();
			travelLeft();
			returnToBot();
			pickBeeper();
			print("haha");
			turnLeft();
			travelLeft();
			print("HOW???");
			//print("test");
			
			//print("test2");
		//}
		//returnToBot();
	}
	public void lineFiller(){// done
		if(facingNorth()){
			//none
		}
		else if(notFacingNorth()){
			if(facingSouth()){
				turnLeft();
				turnLeft();
			}
			if(facingWest()){
				turnLeft();
				turnRight();
			}
			if(facingEast()){
				turnLeft();
			}
			else
				return;
		}
		for(int a = 0; a<8;a++){
			if(noBeepersPresent() && a%2==0)
				putBeeper();
				
			if(frontIsClear()){
				move();
			}
				//print(a);
		}
	}
	public void returnToBot(){// fix this
		while(notFacingSouth()){
			turnLeft();
		}
		for(int a = 0; a<2; a++){
			for(int b = 2; b<4;a++){
				if(noBeepersPresent() && a%2==0)
					putBeeper();
				if(frontIsClear()){
					move();
				}
			}
		}
		
		
	}
	public void travelLeft(){// done
		if(facingEast()){
			move();
		}
		else if(notFacingEast()){
			if(facingSouth()){
				turnLeft();
			}
			else if(facingWest()){
				turnLeft();
				turnLeft();
			}
			else if(facingNorth()){
				turnRight();
			}
			else{
				println("what the");
				return;
			}
			move();
		}
		
	}
	public void dirTest(){
		print("West" + facingWest());
		print("East" + facingEast());
		print("North" + facingNorth());
		print("South" + facingSouth());
	}

}
