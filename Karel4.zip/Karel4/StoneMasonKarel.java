/*
 * File: StoneMasonKarel.java
 * --------------------------
 * The StoneMasonKarel subclass as it appears here does nothing.
 * When you finish writing it, it should solve the "repair the quad"
 * problem from Assignment 1.  In addition to editing the program,
 * you should be sure to edit this comment so that it no longer
 * indicates that the program does nothing.
 */

import stanford.karel.*;

public class StoneMasonKarel extends SuperKarel {

	public void run() {
		//dirTest();
		for(int a = 0; a<3;a++){
			lineFiller();
			returnToBot();
			//print("test");
			travelLeft();
			//print("test2");
		}
		lineFiller();
	}
	public void lineFiller(){
		if(facingNorth()){
			//none
		}
		else if(notFacingNorth()){
			if(facingSouth()){
				turnLeft();
				turnLeft();
			}
			if(facingWest()){
				turnLeft();
				turnRight();
			}
			if(facingEast()){
				turnLeft();
			}
			else
				return;
		}
		for(int a = 0; a<20;a++){
			if(noBeepersPresent())
				putBeeper();
				
			if(frontIsClear()){
				move();
			}
				//print(a);
		}
	}
	public void returnToBot(){
		while(notFacingSouth()){
			turnLeft();
		}
		while(frontIsClear()){
			move();
		}
	}
	public void travelLeft(){
		if(facingEast()){
			move();
			move();
			move();
			move();
		}
		else if(notFacingEast()){
			if(facingSouth()){
				turnLeft();
			}
			else if(facingWest()){
				turnLeft();
				turnLeft();
			}
			else if(facingNorth()){
				turnRight();
			}
			else{
				println("what the");
				return;
			}
			move();
			move();
			move();
			move();
		}
		
	}
	public void dirTest(){
		print("West" + facingWest());
		print("East" + facingEast());
		print("North" + facingNorth());
		print("South" + facingSouth());
	}
}
