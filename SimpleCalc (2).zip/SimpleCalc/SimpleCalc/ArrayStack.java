import java.util.*;
/**
 * Simple stack using Arraylist
 *
 *@author Roko Gebbie 
 * @since February 27, 2024
 */

public class ArrayStack<E> implements Stack<E> {
	private List<E> theStack;
	
	public ArrayStack(){
		theStack = new ArrayList<E>();
	}
	
	/** */
	public boolean isEmpty(){ return theStack.isEmpty();}
	/** */
	public E peek(){
		if(theStack.isEmpty())
			throw new EmptyStackException();
		return theStack.get(theStack.size()-1);
	}
	
	public void push(E obj){
		theStack.add(obj);
	}
	
	public E pop(){
		if(theStack.isEmpty())
			throw new EmptyStackException();
		return theStack.remove(theStack.size()-1);
	}

}
