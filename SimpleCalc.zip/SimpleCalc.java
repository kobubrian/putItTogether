import java.util.List;		// used by expression evaluator
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *	<Description goes here>
 *
 *	@author	Roko Gebbie
 *	@since	3/9/24
 */
public class SimpleCalc {
	final double e = Math.E;
    final double pi = Math.PI;

	private ExprUtils utils;	// expression utilities
    private ArrayStack<Double> valueStack;		// value stack
	private ArrayStack<String> operatorStack;	// operator stack

    private ArrayList<Identifier> identifiers;


	// constructor	
	public SimpleCalc() {
		utils = new ExprUtils();
        valueStack = new ArrayStack<>();
        operatorStack = new ArrayStack<>();
        identifiers = new ArrayList<>();
	}
	
	public static void main(String[] args) {
		SimpleCalc sc = new SimpleCalc();
		sc.run();
	}
	
	public void run() {
		System.out.println("\nWelcome to SimpleCalc!!!");
		runCalc();
		System.out.println("\nThanks for using SimpleCalc! Goodbye.\n");
	}
	
	/**
	 *	Prompt the user for expressions, run the expression evaluator,
	 *	and display the answer.
	 */
	public void runCalc() {
        Scanner input = new Scanner(System.in);
        String line = new String("");
		while(!line.equalsIgnoreCase("q")){
            System.out.print(" -> ");   
            line = input.nextLine();
            List<String> tokens = utils.tokenizeExpression(line);
            if(line.equalsIgnoreCase("h"))
                printHelp();
            else if(line.equals("e"))
                System.out.println(e);
            else if(line.equals("pi"))
                System.out.println(pi);
            else if(line.equalsIgnoreCase("q"))
                continue;
            else if(line.equalsIgnoreCase("l")){
                System.out.println("Variables:");
                for(Identifier id : identifiers)
                    System.out.println("\t"+id.getName() + "\t\t\t" + " = " + "\t\t" + id.getValue());
            }
            else if(tokens.size() > 1 && tokens.get(1).charAt(0) == '='){
                if(isIdentifier(tokens.get(0))){
                    for(Identifier identifier : identifiers){
                        if(identifier.getName().equals(tokens.get(0)))
                            identifier.setValue(evaluateExpression(tokens));
                    }
                }
                else{
                    String namey = tokens.get(0);
                    tokens.remove(0);
                    tokens.remove(0);
                    identifiers.add(new Identifier(evaluateExpression(tokens), namey));
                }
                    
            } 
            else if (!isIdentifier(tokens.get(0)) && Character.isLetter(tokens.get(0).charAt(0))){
                identifiers.add(new Identifier(0.0, tokens.get(0)));
                System.out.println(0.0);
            }
            else{
                System.out.println(evaluateExpression(tokens));
            }

        }
	}
	
	/**	Print help */
	public void printHelp() {
		System.out.println("Help:");
		System.out.println("  h - this message\n  q - quit\n");
		System.out.println("Expressions can contain:");
		System.out.println("  integers or decimal numbers");
		System.out.println("  arithmetic operators +, -, *, /, %, ^");
		System.out.println("  parentheses '(' and ')'");
	}
	
	/**
	 *	Evaluate expression and return the value
	 *	@param tokens	a List of String tokens making up an arithmetic expression
	 *	@return			a double value of the evaluated expression
	 */
	public double evaluateExpression(List<String> tokens) {
        for (int i = 0; i < tokens.size(); i++) {
            if (isNumber(tokens.get(i))) {
                valueStack.push(Double.parseDouble(tokens.get(i)));
            } else if(tokens.get(i).equals("pi") || tokens.get(i).equals("pi")){
                if(tokens.get(i).equals("pi"))
                    valueStack.push(pi);
                else   
                    valueStack.push(e);
            }else if(isIdentifier(tokens.get(i))){
                valueStack.push(identifierValue(tokens.get(i)));
            } else if (isOperator(tokens.get(i))) {
                while (!operatorStack.isEmpty() && precedence(operatorStack.peek()) >= precedence(tokens.get(i))) {
                    processOperator();
                }
                operatorStack.push(tokens.get(i));
            } else if (tokens.get(i).equals("(")) {
                operatorStack.push(tokens.get(i));
            } else if (tokens.get(i).equals(")")) {
                while (!operatorStack.peek().equals("(")) {
                    processOperator();
                }
                operatorStack.pop(); // Discard the "("
            }
        }

        while (!operatorStack.isEmpty()) {
            processOperator();
        }

        return valueStack.pop(); // Final result should be at the top of valueStack
    }

    public void processOperator() {
        double b = valueStack.pop();
        double a = valueStack.pop();
        String operator = operatorStack.pop();
        switch (operator) {
            case "+":
                valueStack.push(a + b);
                break;
            case "-":
                valueStack.push(a - b);
                break;
            case "*":
                valueStack.push(a * b);
                break;
            case "/":
                valueStack.push(a / b);
                break;
            case "^":
                valueStack.push(Math.pow(a,b));
                break;
            case "%":
                valueStack.push(a % b);
                break;
        }
    }

    public int precedence(String operator) {
        switch (operator) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            default:
                return 0; // Parentheses have the lowest precedence
        }
    }

    public boolean isNumber(String token) {
        if(Character.isDigit(token.charAt(0))){
            return true;
        }
        else
            return false;
    }
    public boolean isIdentifier(String token){//TODO: this is new so double check
        for(Identifier identifier : identifiers){
            if(identifier.getName().equals(token))
                return true;
        }
        return false;
    }
    public double identifierValue(String token){
        for(Identifier identifier : identifiers){
            if(identifier.getName().equals(token))
                return identifier.getValue();
        }
        return 0.0;
    }
    public boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/") || token.equals("%") || token.equals("^");
    }
	
	/**
	 *	Precedence of operators
	 *	@param op1	operator 1
	 *	@param op2	operator 2
	 *	@return		true if op2 has higher or same precedence as op1; false otherwise
	 *	Algorithm:
	 *		if op1 is exponent, then false
	 *		if op2 is either left or right parenthesis, then false
	 *		if op1 is multiplication or division or modulus and 
	 *				op2 is addition or subtraction, then false
	 *		otherwise true
	 */
	private boolean hasPrecedence(String op1, String op2) {
		if (op1.equals("^")) return false;
		if (op2.equals("(") || op2.equals(")")) return false;
		if ((op1.equals("*") || op1.equals("/") || op1.equals("%")) 
				&& (op2.equals("+") || op2.equals("-")))
			return false;
		return true;
	}

}
