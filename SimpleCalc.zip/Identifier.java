
public class Identifier {
    private String name;
    private double value;
    public Identifier(double newValue, String newName){
        name = newName;
        value = newValue;
    }
    public String getName(){
        return name;
    }
    public double getValue(){
        return value;
    }
    public void setValue(double newValue){
        value = newValue;
    }
    public void setName(String newName){
        name = newName;
    }
}