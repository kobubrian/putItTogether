import java.awt.Font;
import java.util.Scanner;

/**
 *	HTMLRender
 *	This program renders HTML code into a JFrame window.
 *	It requires your HTMLUtilities class and
 *	the SimpleHtmlRenderer and HtmlPrinter classes.
 *
 *	The tags supported:
 *		<html>, </html> - start/end of the HTML file
 *		<body>, </body> - start/end of the HTML code
 *		<p>, </p> - Start/end of a paragraph.
 *					Causes a newline before and a blank line after. Lines are restricted
 *					to 80 characters maximum.
 *		<hr>	- Creates a horizontal rule on the following line.
 *		<br>	- newline (break)
 *		<b>, </b> - Start/end of bold font print
 *		<i>, </i> - Start/end of italic font print
 *		<q>, </q> - Start/end of quotations
 *		<hX>, </hX> - Start/end of heading with size X = 1, 2, 3, 4, 5, 6
 *		<pre>, </pre> - Preformatted text
 *
 *	@author
 *	@version
 */
public class HTMLRender {
	
	// the array holding all the tokens of the HTML file
	private String [] tokens;
	// SimpleHtmlRenderer fields
	private SimpleHtmlRenderer render;
	private HtmlPrinter browser;
	
		
	public HTMLRender() {	
		// Initialize token array
		tokens = new String[0];
		
		// Initialize Simple Browser
		render = new SimpleHtmlRenderer();
		browser = render.getHtmlPrinter();
	}
	
	
	public static void main(String[] args) {
        HTMLRender hf = new HTMLRender();
		Scanner input = null;
        HTMLUtilities util = new HTMLUtilities();
		String fileName = "";
		// if the command line contains the file name, then store it
		if (args.length > 0)
			fileName = args[0];
		// otherwise print out usage message
		else {
			System.out.println("Usage: java HTMLTester <htmlFileName>");
			System.exit(0);
		}
		
		// Open the HTML file
		input = FileUtils.openToRead(fileName);
		
		// Read each line of the HTML file, tokenize, then print tokens
        String[] newArray = new String[100000];
        int backLength = 0;
        int index = 0; 
		while (input.hasNext()) {
			String line = input.nextLine();
			String [] tokensBack = util.tokenizeHTMLString(line);
            backLength += tokensBack.length;
            for(int i = 0; i < tokensBack.length;i++){
                newArray[index] = tokensBack[i];
                index++;
            }
		}
        hf.tokens = new String[backLength];
        for(int b = backLength -1; b>0; b--){
            hf.tokens[b] = newArray[b];
            //System.out.println(hf.tokens[b]); //test
        }
        //System.out.println("lengthback: " +hf.tokens.length); //test
		input.close();
		hf.run();
	}
	
	public void run() {
        int lineLength = 0;
        int maxLineLength = 80;
        boolean isPre = false;
        boolean isItalic = false;
        boolean isBody = false;
        boolean isPara = false;
        boolean isComment = false;
        boolean isBold = false;
        boolean isH1 = false;
        boolean isH2 = false;
        boolean isH3 = false;
        boolean isH4 = false;
        boolean isH5 = false;
        boolean isH6 = false;
		for(int i = 1; i<tokens.length; i++){
            String str = tokens[i];
            if(str.length() + lineLength > maxLineLength){
                browser.println();
                lineLength = 0;
            }


            if(str.equalsIgnoreCase("</html>")) 
                break;//idk
            else if(str.equalsIgnoreCase("<br>")){
                browser.println();
                browser.println();
                lineLength = 0;
            }
            else if(str.equalsIgnoreCase("<hr>")){
                browser.printHorizontalRule();
                lineLength = 0;//TODO: SUSSY
            }
            else if(str.equalsIgnoreCase("<q>")|| str.equalsIgnoreCase("</q>")){
                if(isBold)
                    browser.printBold("\"");
                else if(isItalic)
                    browser.printItalic("\"");
                else
                    browser.print("\"");
            }
            else if (str.equalsIgnoreCase("<pre>") || str.equalsIgnoreCase("</pre>")) {
                isPre = !isPre;
                maxLineLength = Integer.MAX_VALUE;
            } else if (str.equalsIgnoreCase("<i>") || str.equalsIgnoreCase("</i>")) {
                isItalic = !isItalic;
                maxLineLength = 80;
            } else if (str.equalsIgnoreCase("<b>") || str.equalsIgnoreCase("</b>")) {
                isBold = !isBold;
                maxLineLength = 80;
            } else if (str.equalsIgnoreCase("<h1>") || str.equalsIgnoreCase("</h1>")) {
                isH1 = !isH1;
                maxLineLength = 40;
                lineLength = 0; 
                if(!isH1){
                    browser.println();
                    browser.println();
                }
            } else if (str.equalsIgnoreCase("<h2>") || str.equalsIgnoreCase("</h2>")) {
                isH2 = !isH2;
                maxLineLength = 50;
                lineLength = 0; 
                if(!isH2){
                    browser.println();
                    browser.println();
                }
            } else if (str.equalsIgnoreCase("<h3>") || str.equalsIgnoreCase("</h3>")) {
                isH3 = !isH3;
                maxLineLength = 60;
                lineLength = 0; 
                if(!isH3){
                    browser.println();
                    browser.println();
                }
            } else if (str.equalsIgnoreCase("<h4>") || str.equalsIgnoreCase("</h4>")) {
                isH4 = !isH4;
                maxLineLength = 80;
                lineLength = 0;
                if(!isH4){
                    browser.println();
                    browser.println();
                } 
            } else if (str.equalsIgnoreCase("<h5>") || str.equalsIgnoreCase("</h5>")) {
                isH5 = !isH5;
                maxLineLength = 100;
                lineLength = 0; 
                if(!isH5){
                    browser.println();
                    browser.println();
                }
            } else if (str.equalsIgnoreCase("<h6>") || str.equalsIgnoreCase("</h6>")) {
                isH6 = !isH6;
                maxLineLength = 120;    
                lineLength = 0; 
                if(!isH6){
                    browser.println();
                    browser.println();
                }
            } else if (str.equalsIgnoreCase("<!--") || str.equalsIgnoreCase("-->")) {
                isComment = !isComment; 
                maxLineLength = 80;
            } else if (str.equalsIgnoreCase("<body>") || str.equalsIgnoreCase("</body>")) {
                isBody = !isBody; 
            }else if (str.equalsIgnoreCase("<p>") || str.equalsIgnoreCase("</p>")) {
                isPara = !isPara; 
                if(!isPara){
                    browser.println();
                    browser.println();
                    lineLength = 0;
                }
                else{
                    browser.println();
                    browser.println();
                    lineLength = 0;
                }
            }
            else{
                if(isH1){
                    browser.printHeading1(str + " ");
                }else if (isH2) {
                    browser.printHeading2(str+ " ");
                } else if (isH3) {
                    browser.printHeading3(str+ " ");
                } else if (isH4) {
                    browser.printHeading4(str+ " ");
                } else if (isH5) {
                    browser.printHeading5(str+ " ");
                } else if (isH6) {
                    browser.printHeading6(str+ " ");
                }
                else if(isBody){
                    if (isPre){
                        browser.printPreformattedText(str +" ");
                        browser.println();
                    }
                    else{
                        if(isBold){
                            browser.printBold(str+ " ");
                        }   
                        else if(isItalic){
                            browser.printItalic(str+ " ");
                        }
                        else{
                            browser.print(str+" ");
                        }
                    }
                }
                if(!isPre){
                    lineLength += (str.length() +1);
                }
            }
        }
        /*System.out.println(tokens[0]);
        System.out.println(tokens[1]);  // TEST
        System.out.println(tokens[2]);*/
        
        
        
        
        
        
        
        
        /* 
        // Sample renderings from HtmlPrinter class
		
		// Print plain text without line feed at end
		browser.print("First line");
		
		// Print line feed
		browser.println();
		
		// Print bold words and plain space without line feed at end
		browser.printBold("bold words");
		browser.print(" ");
		
		// Print italic words without line feed at end
		browser.printItalic("italic words");
		
		// Print horizontal rule across window (includes line feed before and after)
		browser.printHorizontalRule();
		
		// Print words, then line feed (printBreak)
		browser.print("A couple of words");
		browser.printBreak();
		browser.printBreak();
		
		// Print a double quote
		browser.print("\"");
		
		// Print Headings 1 through 6 (Largest to smallest)
		browser.printHeading1("Heading1");
		browser.printHeading2("Heading2");
		browser.printHeading3("kill yourself");
		browser.printHeading4("Heading4");
		browser.printHeading5("Heading5");
		browser.printHeading6("Heading6");
		
		// Print pre-formatted text (optional)
		browser.printPreformattedText("Preformat Monospace\tfont");
		browser.printBreak();
		browser.print("The end");
		*/
	}
	
}

