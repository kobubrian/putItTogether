/**
 * @author Roko Gebbie
 * @since 3/21/24
 * 
*/

import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.awt.Color;

public class RockHound extends Critter{
	int turnCount;
	
	 /**
     * Constructs a blue JumperBug.
     */
	public RockHound(){
		setColor(Color.BLUE);
		turnCount = 0;
	}
	/**
	 * moves the bug around
	 */
	public void act(){
		super.act();
	}
}  

