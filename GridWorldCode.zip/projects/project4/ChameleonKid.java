/**
 * @author Roko Gebbie
 * @since 3/21/24
 * 
*/

import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.awt.Color;
import java.util.ArrayList; 

public class ChameleonKid extends Critter{
	int turnCount;
	ArrayList<Location> locs; 
	 /**
     * Constructs a blue JumperBug.
     */
	public ChameleonKid(){
		turnCount = 0;
		
				
	}
	/**
	 * moves the bug around
	 */
	public void act(){
		Location go = selectMoveLocation(getMoveLocations());
		makeMove(go);
		processActors(getActors());
	}  
	public void processActors(ArrayList<Actor> actors){
		if(actors.size() > 0){
			int closestIndex = 0; 
			double closestDistance = Double.POSITIVE_INFINITY; 
			for(int i = 0 ; i < actors.size(); i++){
				double distance = (int) Math.sqrt(Math.pow(getLocation().getRow() - actors.get(i).getLocation().getRow(), 2) + Math.pow(getLocation().getCol() - actors.get(i).getLocation().getCol(), 2));
				if(distance < closestDistance){
					closestDistance = distance;
					closestIndex = i;
				}
			}
			setColor(actors.get(closestIndex).getColor());
		}
	}
	public void makeMove(Location loc){
		setDirection(getLocation().getDirectionToward(loc));
		super.makeMove(loc);
	}
}
