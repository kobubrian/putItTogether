/*
 * File: NewImprovedKarel.java
 * -----------------------------
 * The NewImprovedKarel class extends the basic Karel class
 * so that Karel has two new features: turnRight() and turnAround().
 * This demonstrates ENCAPSULATION.
 */

import stanford.karel.*;

public class NewImprovedKarel extends Karel {
	public NewImprovedKarel(){
		super();
	}
	/*	Demonstration of ENCAPSULATION
	 *	Provide an extra service but hide the information about it.
	 *
	 *	The following methods are encapsulated into NewImprovedKarel class.
	 */
	public void turnRight() {	
		System.out.println("testt");
		turnAround();
		//turnLeft();
		System.out.println("testt2");
	}
	
	public void turnAround() {
		System.out.println("testt3");
		//turnLeft();
		//turnLeft();
		System.out.println("testt4");
	}
    
}
