/**
 *	Utilities for handling HTML
 *
 *	@author	Roko Gebbie
 *	@since	11/16/23
 */
public class HTMLUtilities {
	private enum TokenState { NONE, COMMENT, PRE };
	private TokenState state = TokenState.NONE; 

	/**
	 *	Break the HTML string into tokens. The array returned is
	 *	exactly the size of the number of tokens in the HTML string.
	 *	Example:	HTML string = "Goodnight moon goodnight stars"
	 *				returns { "Goodnight", "moon", "goodnight", "stars" }
	 *	@param str			the HTML string
	 *	@return				the String array of tokens
	 */
	public String[] tokenizeHTMLString(String str) {
		// make the size of the array large to start
		String[] result = new String[10000];
		
		String token = "";// current token duh
		int htmlIndex = 0;// increment for main loop
		int tokenCount = 0;// how many tokens in total
		int index = 0;// inside the main loop
		while (htmlIndex < str.length()) {// line loop
			boolean checkLines = htmlIndex + 4 < str.length();
            // detect start comment in html<!-- 
			if (checkLines && str.substring(htmlIndex, htmlIndex + 4).equals("<!--")) {
				state = TokenState.COMMENT;
				htmlIndex += 4;
			}// detect start preformat <pre> 
			else if ((htmlIndex + 4) < str.length() && str.substring(htmlIndex).equals("<pre>")) {
				state = TokenState.PRE;
				tokenCount++;
				token = "<pre>";
				result[index] = token;
				index++;
				htmlIndex = str.length(); 
			}// detect end comment "-->"
			else if ((htmlIndex + 2) < str.length() && str.substring(htmlIndex).equals("-->")) {
				state = TokenState.NONE;
				htmlIndex += 2;
			}// detect end comment "-->"
			else if ((htmlIndex + 3) < str.length() && str.substring(htmlIndex, htmlIndex + 3).equals("-->")) {
				state = TokenState.NONE;
				htmlIndex += 3;
			}// detect end preformat </pre> 
			else if ((htmlIndex + 5) < str.length() && str.substring(htmlIndex).equals("</pre>")) {
				state = TokenState.NONE;
				tokenCount++;
				token = "</pre>";
				result[index] = token;
				index++;
				htmlIndex = str.length(); 
			} 
            //Handle text inside of <pre> tags
			if (state == TokenState.PRE && token.equals("")) {
				tokenCount++;
				token += str;
				result[index] = token;
				index++;
				htmlIndex = str.length();
			}
			// handle normal text (not comment or preformatted)
			if (htmlIndex < str.length() && state == TokenState.NONE) {
			    
				if (str.charAt(htmlIndex) == '<') {
					tokenCount++;
					int modLength = htmlIndex;
					while (str.charAt(modLength) != '>') {
						token += str.charAt(modLength);
						modLength++;
					}
					token += str.charAt(modLength);
					htmlIndex = modLength;
					result[index] = token;
					index++;
				}
				else if (Character.isLetter(str.charAt(htmlIndex))) {
					tokenCount++;
					int tokenLength = htmlIndex;
					while (tokenLength < str.length() && Character.isLetter(str.charAt(tokenLength))) {
						token += str.charAt(tokenLength);
						tokenLength++;
					}
					htmlIndex = tokenLength-1;
					result[index] = token;
					index++;
				}
				else if (Character.isDigit(str.charAt(htmlIndex))) {
					tokenCount++;
					int numLength = htmlIndex;
					if (numLength != 0 && str.charAt(numLength-1) == '-') {
						tokenCount--;
						index--;
						token += str.charAt(numLength-1);
					}
					
					while (numLength < str.length() && Character.isDigit(str.charAt(numLength))) {
						token += str.charAt(numLength);
						numLength++;
						
						while (numLength < str.length() && (str.charAt(numLength) == '.' || str.charAt(numLength) == 'e' || str.charAt(numLength) 
						== '-')) {
							token += str.charAt(numLength);
							numLength++;
						}
					}
					
					htmlIndex = numLength-1;
					result[index] = token;
					index++;
				}
				else if (".,;:()?!=&~+-".indexOf(str.charAt(htmlIndex)) != -1) {
                    tokenCount++;
                    token += str.charAt(htmlIndex);
                    result[index] = token;
                    index++;
                }
				
			}
			token = "";
			htmlIndex++;
		}
		
		String[] finalAnswer = new String[tokenCount];
		for (int i = 0; i < finalAnswer.length; i++) {
			finalAnswer[i] = result[i];
		}
		return finalAnswer;
	}
	
	/**
	 *	Print the tokens in the array to the screen
	 *	Precondition: All elements in the array are valid String objects.
	 *				(no nulls)
	 *	@param tokens		an array of String tokens
	 */
	public void printTokens(String[] tokens) {
		if (tokens == null) return;
		for (int a = 0; a < tokens.length; a++) {
			if (a % 5 == 0) System.out.print("\n  ");
			System.out.print("[token " + a + "]: " + tokens[a] + " ");
		}
		System.out.println();
	}
	
}
